// By M
package com.mycompany.finalprojectadprog;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class SecondaryController {
    private Stage stage;
    private Scene scene;
    private Parent root;

    // Method to switch to Add Student Screen
    @FXML
    public void goToAddStudent(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("AddStudent.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    // Method to switch to Add Grades Screen
    @FXML
    public void goToAddGrade(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("AddGrade.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    // Method to switch to View Students Screen (Your Screen)
    @FXML
    public void goToViewStudents(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("ViewStudents.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    // Method to handle Logout and return to Login Screen
    @FXML
    public void handleLogout(ActionEvent event) throws IOException {
    root = FXMLLoader.load(getClass().getResource("primary.fxml")); 
    stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    scene = new Scene(root);
    stage.setScene(scene);
    stage.show();
    }

    @FXML
    private void switchToPrimary() throws IOException {
        
    }// end switch
}// end class sec