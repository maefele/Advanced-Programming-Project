//By S S
package com.mycompany.finalprojectadprog;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.event.ActionEvent;

public class AddStudent {

    @FXML
    private TextField nameInput;
 
    @FXML
    private TextField idInput;

    @FXML
    public void switchToSecondary(ActionEvent event) throws IOException {
        
        String studentName = nameInput.getText();
        String studentId = idInput.getText();

        if (studentName.isEmpty() || studentId.isEmpty()) {
            System.out.println("fill everything");
            return; 
        }

        try (FileWriter writer = new FileWriter("students_data.txt", true);
             BufferedWriter bw = new BufferedWriter(writer)) {
             
            bw.write(studentId + "," + studentName);
            bw.newLine();
        System.out.println("Successfully saved: Name: " + studentName + " | ID: " + studentId); 
        } catch (IOException e) {
            System.out.println("Save Intrurrupted");
            e.printStackTrace();
            return; 
        }

        App.setRoot("secondary");
    }
}