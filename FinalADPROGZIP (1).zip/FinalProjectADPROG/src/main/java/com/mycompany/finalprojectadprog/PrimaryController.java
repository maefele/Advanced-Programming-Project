//by L
package com.mycompany.finalprojectadprog;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class PrimaryController {

    @FXML
    private Label ID;

    @FXML
    private TextField IDinput;

    @FXML
    private Button LoginButton;

    @FXML
    private Label Name;

    @FXML
    private TextField nameInput;

    @FXML
    private Label pass;

    @FXML
    private TextField passInput;

    @FXML
    private Label welcApp;

    @FXML
    void switchToSecondary(ActionEvent event) {
        String enterName = nameInput.getText();
        String enterID = IDinput.getText();
        String enterPasw = passInput.getText();
        
        // check if empty
    if (enterName.isEmpty() || enterID.isEmpty() || enterPasw.isEmpty()) {
        welcApp.setText("Please fill all fields!");
        return;
    }//end empty check
    
    // user input shpuld be
    if (enterName.equals("Layal") && enterID.equals("446003747") && enterPasw.equals("777Layal")) {
        changeScene();
    } else if (enterName.equals("Samaa") && enterID.equals("446002093") && enterPasw.equals("999Samaa")) {
        changeScene();
    } else if (enterName.equals("Shamayil") && enterID.equals("44610372") && enterPasw.equals("666Shamayil")) {
        changeScene();
    } else if (enterName.equals("Maareb") && enterID.equals("44611014") && enterPasw.equals("888Maareb")) {
        changeScene();
    } else {
        // if wrong input
        welcApp.setText("Wrong ID or Password!");
    }//end user input


    }//end switch
    private void changeScene() {
    javafx.application.Platform.runLater(() -> {
        try {
            App.setRoot("secondary");
        } catch (Exception e) {
            welcApp.setText("Error: can't load next screen.");
            e.printStackTrace();
        }
    });
}

}// end prim class
