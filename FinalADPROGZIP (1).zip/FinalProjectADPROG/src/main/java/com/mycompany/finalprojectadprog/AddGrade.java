// By S
package com.mycompany.finalprojectadprog;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class AddGrade {

    @FXML
    private TextField grade;

    @FXML
    private TextField idInput;

    @FXML
    private Button secondaryButton;

    @FXML
    void switchToPrimary(ActionEvent event) {
        
        String targetId = idInput.getText();
        String studentGrade = grade.getText();

        if (targetId == null || targetId.trim().isEmpty() || 
            studentGrade == null || studentGrade.trim().isEmpty()) {
            System.out.println("fill everything");
            return;
        }

        File file = new File("students_data.txt");
        if (!file.exists()) {
            System.out.println("No students data found");
            return;
        }

        ArrayList<String> lines = new ArrayList<>();
        boolean studentFound = false;
        String studentName = "";

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 2 && parts[0].equals(targetId)) {
                    studentName = parts[1];
                    line = parts[0] + "," + parts[1] + "," + studentGrade;
                    studentFound = true;
                }
                lines.add(line);
            }
        } catch (IOException e) {
            System.out.println("Read error");
            return;
        }

        if (studentFound) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, false))) {
                for (String l : lines) {
                    writer.write(l);
                    writer.newLine();
                }
                
                System.out.println("Saved Info -> ID: " + targetId + " | Name: " + studentName + " | Grade: " + studentGrade);
                
                grade.clear();
                idInput.clear();
                
                try {
                    App.setRoot("secondary");
                } catch (IOException e) {
                  System.out.println("Failed to load dashboard screen.");
                }
                
            } catch (IOException e) {
                System.out.println("Write error");
            }
        } else {
            System.out.println("Student ID not found");
        }
    }
}