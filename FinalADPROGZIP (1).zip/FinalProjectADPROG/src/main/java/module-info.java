module com.mycompany.finalprojectadprog {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.mycompany.finalprojectadprog to javafx.fxml;
    exports com.mycompany.finalprojectadprog;
}
