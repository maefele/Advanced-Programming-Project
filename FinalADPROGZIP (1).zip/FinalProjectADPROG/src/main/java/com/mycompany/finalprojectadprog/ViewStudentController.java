//By M
package com.mycompany.finalprojectadprog;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javafx.scene.control.Label;

public class ViewStudentController {

    @FXML private TableView<Student> studentTable;
    @FXML private TableColumn<Student, String> idColumn;
    @FXML private TableColumn<Student, String> nameColumn;
    @FXML private TableColumn<Student, String> gradeColumn; 
    @FXML private Label averageLabel;

    private ObservableList<Student> studentList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        // Linked table columns to Student properties (id, name, grade)
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        gradeColumn.setCellValueFactory(new PropertyValueFactory<>("grade"));

        // Load data from the shared text file
        loadStudentData();
    }

    private void loadStudentData() {
        double totalGrades = 0;
        int gradedStudentsCount = 0;

        //Reading from "students_data.txt"
        try (BufferedReader reader = new BufferedReader(new FileReader("students_data.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                
                // Safe checks for different data configurations
                if (data.length >= 2) {
                    String id = data[0].trim();
                    String name = data[1].trim();
                    String grade = "No Grade"; // Default value
                    
                    if (data.length >= 3) {
                        grade = data[2].trim();
                        try {
                            // Try to parse the string grade to a number for calculations
                            double numericGrade = Double.parseDouble(grade);
                            totalGrades += numericGrade;
                            gradedStudentsCount++;
                        } catch (NumberFormatException e) {
                            // In case the grade string isn't a valid decimal number
                            System.out.println("Non-numeric grade skipped for calculation: " + grade);
                        }
                    }
                    
                    studentList.add(new Student(id, name, grade));
                }
            }
            studentTable.setItems(studentList);
            
            // Calculate and display the average grade
            if (gradedStudentsCount > 0) {
                double average = totalGrades / gradedStudentsCount;
                averageLabel.setText(String.format("Average Grade: %.2f", average));
            } else {
                averageLabel.setText("Average Grade: No graded students available");
            }

        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
            averageLabel.setText("Average Grade: Error loading data");
        }
    }

    // Method to go back to Dashboard
    @FXML
    public void goToDashboard(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("secondary.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}